import { useState, useCallback } from 'react';
import Navbar from '@/components/Navbar';
import RadarMap from '@/components/RadarMap';
import DispatchPanel from '@/components/DispatchPanel';
import ScanModal from '@/components/ScanModal';
import Toast, { LowBandwidthBanner, type ToastData } from '@/components/Toast';
import LowBandwidthView from '@/components/LowBandwidthView';
import { initialPins, initialReports, initialDispatches } from '@/data';
import type { OutbreakPin, SMSDispatch, ScanResult, Report } from '@/types';

function App() {
  const [lowBandwidth, setLowBandwidth] = useState(false);
  const [scanOpen, setScanOpen] = useState(false);
  const [pins, setPins] = useState<OutbreakPin[]>(initialPins);
  const [reports, setReports] = useState<Report[]>(initialReports);
  const [dispatches, setDispatches] = useState<SMSDispatch[]>(initialDispatches);
  const [toasts, setToasts] = useState<ToastData[]>([]);
  const [activeFilter, setActiveFilter] = useState('All Crops');
  const [spreadPredictor, setSpreadPredictor] = useState(false);

  const addToast = useCallback((type: ToastData['type'], title: string, message: string) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [...prev, { id, type, title, message }]);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const handleTestBroadcast = useCallback(() => {
    const newDispatch: SMSDispatch = {
      id: `d-${Date.now()}`,
      message:
        '🚨 ALERT: Tomato Late Blight confirmed 2.1km from your field. High humidity tonight favors spore spread. Action: Apply Mancozeb or organic copper spray within 24h. Reply 1 for nearest fungicide depot.',
      recipients: 38,
      sector: 'Sector 4',
      time: 'Just now',
      status: 'sent',
    };
    setDispatches((prev) => [newDispatch, ...prev]);
    addToast('success', 'Broadcast Sent', 'SMS & WhatsApp alert dispatched to 38 registered smallholders in Sector 4');
  }, [addToast]);

  const handleBroadcast = useCallback(
    (result: ScanResult) => {
      setScanOpen(false);

      const cropTypeMap: Record<string, OutbreakPin['cropType']> = {
        Tomato: 'tomato',
        Maize: 'maize',
        Wheat: 'wheat',
        Rice: 'rice',
        Potato: 'potato',
      };

      const newPin: OutbreakPin = {
        id: `pin-${Date.now()}`,
        crop: result.crop,
        cropType: cropTypeMap[result.crop] ?? 'tomato',
        pest: result.disease,
        scientificName: result.scientificName,
        severity: result.severity,
        distanceKm: 0.5,
        x: 50,
        y: 50,
        date: 'Oct 14, 2026',
        time: 'Just now',
        humidity: 84,
        windSpeed: 14,
        windDirection: 'North-East',
        organicRemedies: result.organicRemedies,
        chemicalControls: result.chemicalControls,
        reporter: 'You (Field Report)',
        verified: false,
      };

      setPins((prev) => [...prev, newPin]);

      const emojiMap: Record<string, string> = {
        Tomato: '🍅',
        Maize: '🌽',
        Wheat: '🌾',
        Rice: '🌾',
        Potato: '🥔',
      };

      const newReport: Report = {
        id: `r-${Date.now()}`,
        crop: result.crop,
        cropType: result.crop.toLowerCase(),
        pest: result.disease,
        distanceKm: 0.5,
        timeAgo: 'Just now',
        verified: false,
        reporter: 'You',
        emoji: emojiMap[result.crop] ?? '🌱',
      };

      setReports((prev) => [newReport, ...prev]);

      const newDispatch: SMSDispatch = {
        id: `d-${Date.now()}`,
        message: `🚨 NEW OUTBREAK: ${result.disease} confirmed on ${result.crop} at your location. ${result.recommendation} Reply 1 for treatment depot.`,
        recipients: 38,
        sector: 'Your Sector',
        time: 'Just now',
        status: 'sent',
      };

      setDispatches((prev) => [newDispatch, ...prev]);

      addToast('success', 'Outbreak Pinned', 'Outbreak pinned to community radar. 38 neighboring farms alerted.');
    },
    [addToast]
  );

  return (
    <div className="min-h-screen bg-slate-950">
      <Navbar
        lowBandwidth={lowBandwidth}
        onToggleLowBandwidth={() => setLowBandwidth(!lowBandwidth)}
        onOpenScan={() => setScanOpen(true)}
      />

      {lowBandwidth && <LowBandwidthBanner />}

      {/* Stats bar */}
      <div className="border-b border-slate-800 bg-slate-900/30 px-4 py-2.5 md:px-6">
        <div className="flex flex-wrap items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-red-500" />
            <span className="text-slate-400">
              <span className="font-bold text-white">{pins.filter((p) => p.severity === 'critical').length}</span> Critical
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-amber-500" />
            <span className="text-slate-400">
              <span className="font-bold text-white">{pins.filter((p) => p.severity === 'warning').length}</span> Warning
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            <span className="text-slate-400">
              <span className="font-bold text-white">{pins.filter((p) => p.severity === 'resolved').length}</span> Resolved
            </span>
          </div>
          <div className="hidden h-4 w-px bg-slate-700 sm:block" />
          <div className="flex items-center gap-1.5 text-slate-400">
            <span className="font-bold text-white">{dispatches.reduce((sum, d) => sum + d.recipients, 0)}</span> farmers notified
          </div>
          <div className="hidden h-4 w-px bg-slate-700 sm:block" />
          <div className="flex items-center gap-1.5 text-slate-400">
            <span className="font-bold text-emerald-400">42</span> nodes online
          </div>
        </div>
      </div>

      {/* Main content */}
      <main className="px-4 py-4 md:px-6">
        {lowBandwidth ? (
          <div className="mx-auto max-w-5xl space-y-4 animate-fade-in">
            <LowBandwidthView pins={pins} />
          </div>
        ) : (
          <div className="flex flex-col gap-4 lg:flex-row animate-fade-in">
            {/* Left column - Map (65%) */}
            <div className="lg:w-[65%]">
              <RadarMap
                pins={pins}
                activeFilter={activeFilter}
                onFilterChange={setActiveFilter}
                spreadPredictor={spreadPredictor}
                onToggleSpreadPredictor={() => setSpreadPredictor(!spreadPredictor)}
              />
            </div>

            {/* Right column - Dispatch & Feed (35%) */}
            <div className="lg:w-[35%]">
              <DispatchPanel
                dispatches={dispatches}
                reports={reports}
                onTestBroadcast={handleTestBroadcast}
              />
            </div>
          </div>
        )}
      </main>

      {/* Scan Modal */}
      {scanOpen && <ScanModal onClose={() => setScanOpen(false)} onBroadcast={handleBroadcast} />}

      {/* Toasts */}
      <Toast toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}

export default App;
