import type { OutbreakPin, Report, SMSDispatch } from '../types';
import {
  Smartphone,
  Send,
  Radio,
  CheckCircle2,
  Clock,
  Bell,
  MessageSquare,
  MapPin,
  AlertTriangle,
  Signal,
  Battery,
  Wifi,
} from 'lucide-react';

interface DispatchPanelProps {
  dispatches: SMSDispatch[];
  reports: Report[];
  onTestBroadcast: () => void;
}

export default function DispatchPanel({ dispatches, reports, onTestBroadcast }: DispatchPanelProps) {
  return (
    <div className="flex h-full flex-col gap-4 overflow-y-auto scrollbar-thin">
      {/* SMS Gateway */}
      <SMSGateway dispatches={dispatches} onTestBroadcast={onTestBroadcast} />

      {/* Reports Feed */}
      <ReportsFeed reports={reports} />
    </div>
  );
}

function SMSGateway({ dispatches, onTestBroadcast }: { dispatches: SMSDispatch[]; onTestBroadcast: () => void }) {
  return (
    <div className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/50">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900/80 px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-700">
            <Radio className="h-4 w-4 text-white" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">SMS & WhatsApp Gateway</h3>
            <p className="text-[10px] text-slate-500">Automated Broadcast Engine (Twilio Simulated)</p>
          </div>
        </div>
        <span className="flex items-center gap-1 rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-medium text-emerald-400">
          <span className="relative flex h-1.5 w-1.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-500" />
          </span>
          Live
        </span>
      </div>

      {/* Phone frame */}
      <div className="p-4">
        <div className="mx-auto max-w-[320px] overflow-hidden rounded-2xl border-2 border-slate-700 bg-slate-950 shadow-xl">
          {/* Phone status bar */}
          <div className="flex items-center justify-between bg-slate-900 px-4 py-1.5">
            <span className="text-[10px] font-medium text-slate-400">9:41 AM</span>
            <div className="flex items-center gap-1.5">
              <Signal className="h-3 w-3 text-slate-400" />
              <Wifi className="h-3 w-3 text-slate-400" />
              <Battery className="h-3.5 w-3.5 text-slate-400" />
            </div>
          </div>

          {/* Phone header */}
          <div className="flex items-center gap-2 border-b border-slate-800 bg-slate-900/50 px-4 py-2">
            <Smartphone className="h-4 w-4 text-emerald-500" />
            <span className="text-xs font-semibold text-white">Farm Alert Broadcast</span>
            <span className="ml-auto text-[10px] text-slate-500">{dispatches.length} sent today</span>
          </div>

          {/* Messages */}
          <div className="space-y-3 p-3 max-h-[280px] overflow-y-auto scrollbar-thin">
            {dispatches.map((dispatch) => (
              <div key={dispatch.id} className="animate-slide-up space-y-1">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-medium text-slate-500">
                    <Bell className="h-2.5 w-2.5" />
                    {dispatch.sector} • {dispatch.recipients} farmers
                  </span>
                  <span className="flex items-center gap-1 text-[10px] text-emerald-400">
                    <CheckCircle2 className="h-2.5 w-2.5" />
                    {dispatch.status}
                  </span>
                </div>
                <div className="rounded-xl rounded-bl-sm bg-emerald-500/15 px-3 py-2">
                  <p className="text-[11px] leading-relaxed text-slate-200">{dispatch.message}</p>
                  <div className="mt-1.5 flex items-center justify-between">
                    <span className="text-[9px] text-slate-500">{dispatch.time}</span>
                    <span className="flex items-center gap-0.5 text-[9px] text-emerald-400">
                      <MessageSquare className="h-2.5 w-2.5" />
                      SMS + WhatsApp
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="border-t border-slate-800 bg-slate-900/50 p-3">
            <button
              onClick={onTestBroadcast}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-600 px-4 py-2.5 text-xs font-semibold text-white shadow-lg shadow-emerald-500/20 transition-all hover:brightness-110"
            >
              <Send className="h-3.5 w-3.5" />
              Test Emergency Broadcast
            </button>
            <p className="mt-1.5 text-center text-[9px] text-slate-600">
              Sends to all registered smallholders in range
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function ReportsFeed({ reports }: { reports: Report[] }) {
  return (
    <div className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/50">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900/80 px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-800">
            <AlertTriangle className="h-4 w-4 text-amber-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">Recent Outbreak Reports</h3>
            <p className="text-[10px] text-slate-500">Community-submitted field alerts</p>
          </div>
        </div>
        <span className="rounded-full bg-slate-800 px-2 py-0.5 text-[10px] font-medium text-slate-400">
          {reports.length} reports
        </span>
      </div>

      {/* Feed */}
      <div className="max-h-[300px] space-y-1 overflow-y-auto scrollbar-thin p-2">
        {reports.map((report) => (
          <div
            key={report.id}
            className="flex items-center gap-3 rounded-lg p-2 transition-colors hover:bg-slate-800/50"
          >
            {/* Thumbnail */}
            <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-slate-800 text-lg">
              {report.emoji}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <p className="truncate text-xs font-semibold text-white">{report.crop}</p>
                {report.verified && (
                  <CheckCircle2 className="h-3 w-3 flex-shrink-0 text-emerald-400" />
                )}
              </div>
              <p className="truncate text-[11px] text-slate-400">{report.pest}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="flex items-center gap-0.5 text-[10px] text-slate-500">
                  <MapPin className="h-2.5 w-2.5" />
                  {report.distanceKm} km
                </span>
                <span className="flex items-center gap-0.5 text-[10px] text-slate-500">
                  <Clock className="h-2.5 w-2.5" />
                  {report.timeAgo}
                </span>
              </div>
            </div>

            {/* Reporter */}
            <div className="flex-shrink-0 text-right">
              <p className="text-[10px] font-medium text-slate-400">{report.reporter}</p>
              {report.verified ? (
                <span className="text-[9px] text-emerald-400">Verified</span>
              ) : (
                <span className="text-[9px] text-amber-400">Pending</span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
