import type { OutbreakPin } from '../types';
import { AlertTriangle, CheckCircle2, MapPin, Wind } from 'lucide-react';

interface LowBandwidthViewProps {
  pins: OutbreakPin[];
}

export default function LowBandwidthView({ pins }: LowBandwidthViewProps) {
  const sortedPins = [...pins].sort((a, b) => a.distanceKm - b.distanceKm);

  const getAction = (pin: OutbreakPin) => {
    if (pin.severity === 'resolved') return 'No action needed — treated';
    if (pin.severity === 'critical') return `Apply treatment within 24h — ${pin.chemicalControls[0]?.split('—')[0]?.trim() ?? 'See protocol'}`;
    return `Monitor closely — ${pin.organicRemedies[0]?.split('—')[0]?.trim() ?? 'Preventive spray'}`;
  };

  return (
    <div className="rounded-2xl border border-amber-500/20 bg-slate-900/50 overflow-hidden">
      <div className="border-b border-slate-800 bg-slate-900/80 px-4 py-3">
        <h2 className="text-sm font-bold text-white">Active Alerts — Text Mode</h2>
        <p className="text-[10px] text-slate-500">High-contrast lightweight table for 2G connections</p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-950/50 text-[10px] uppercase text-slate-500">
              <th className="px-4 py-2.5 font-medium">Crop</th>
              <th className="px-4 py-2.5 font-medium">Pest / Disease</th>
              <th className="px-4 py-2.5 font-medium">Distance</th>
              <th className="px-4 py-2.5 font-medium">Risk</th>
              <th className="px-4 py-2.5 font-medium">Action</th>
            </tr>
          </thead>
          <tbody>
            {sortedPins.map((pin) => (
              <tr key={pin.id} className="border-b border-slate-800/50 transition-colors hover:bg-slate-800/30">
                <td className="px-4 py-3 font-semibold text-white">{pin.crop}</td>
                <td className="px-4 py-3 text-slate-300">{pin.pest}</td>
                <td className="px-4 py-3">
                  <span className="flex items-center gap-1 text-slate-400">
                    <MapPin className="h-3 w-3" />
                    {pin.distanceKm} km
                  </span>
                </td>
                <td className="px-4 py-3">
                  {pin.severity === 'critical' && (
                    <span className="flex items-center gap-1 font-bold text-red-400">
                      <AlertTriangle className="h-3 w-3" />
                      Critical
                    </span>
                  )}
                  {pin.severity === 'warning' && (
                    <span className="flex items-center gap-1 font-bold text-amber-400">
                      <AlertTriangle className="h-3 w-3" />
                      Warning
                    </span>
                  )}
                  {pin.severity === 'resolved' && (
                    <span className="flex items-center gap-1 font-bold text-emerald-400">
                      <CheckCircle2 className="h-3 w-3" />
                      Resolved
                    </span>
                  )}
                </td>
                <td className="px-4 py-3 text-slate-400 max-w-[280px]">
                  {getAction(pin)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Footer summary */}
      <div className="flex items-center justify-between border-t border-slate-800 bg-slate-950/50 px-4 py-2.5">
        <span className="text-[10px] text-slate-500">
          {sortedPins.filter((p) => p.severity === 'critical').length} critical •{' '}
          {sortedPins.filter((p) => p.severity === 'warning').length} warning •{' '}
          {sortedPins.filter((p) => p.severity === 'resolved').length} resolved
        </span>
        <span className="flex items-center gap-1 text-[10px] text-amber-400">
          <Wind className="h-3 w-3" />
          Wind: 14 km/h NE
        </span>
      </div>
    </div>
  );
}
