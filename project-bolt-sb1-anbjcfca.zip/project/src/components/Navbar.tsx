import { Radar, Wifi, WifiOff, Plus, Activity, Radio } from 'lucide-react';

interface NavbarProps {
  lowBandwidth: boolean;
  onToggleLowBandwidth: () => void;
  onOpenScan: () => void;
}

export default function Navbar({ lowBandwidth, onToggleLowBandwidth, onOpenScan }: NavbarProps) {
  return (
    <nav className="sticky top-0 z-50 border-b border-slate-800 bg-slate-950/90 backdrop-blur-xl">
      <div className="flex items-center justify-between px-4 py-3 md:px-6">
        {/* Logo + Badge */}
        <div className="flex items-center gap-3">
          <div className="relative flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 shadow-lg shadow-emerald-500/30">
            <Radar className="h-6 w-6 text-white" strokeWidth={2.2} />
            <div className="absolute -right-1 -top-1 flex h-3.5 w-3.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex h-3.5 w-3.5 rounded-full bg-emerald-500 border-2 border-slate-950" />
            </div>
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-white md:text-xl">
              Farm Sight Radar
            </h1>
            <div className="flex items-center gap-1.5 text-xs text-emerald-400">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
              </span>
              <span className="font-medium">Grid Active</span>
              <span className="text-slate-600">•</span>
              <span className="text-slate-400">42 Regional Nodes Connected</span>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2 md:gap-3">
          {/* Node Activity indicator */}
          <div className="hidden items-center gap-2 rounded-lg border border-slate-800 bg-slate-900/60 px-3 py-2 lg:flex">
            <Activity className="h-4 w-4 text-emerald-500" />
            <span className="text-xs font-medium text-slate-400">12 Active Alerts</span>
            <Radio className="h-3.5 w-3.5 text-amber-500" />
          </div>

          {/* 2G Toggle */}
          <button
            onClick={onToggleLowBandwidth}
            className={`group flex items-center gap-2 rounded-lg border px-3 py-2 transition-all duration-300 ${
              lowBandwidth
                ? 'border-amber-500/50 bg-amber-500/10'
                : 'border-slate-700 bg-slate-900/60 hover:border-slate-600'
            }`}
          >
            <div className={`relative h-5 w-9 rounded-full transition-colors ${lowBandwidth ? 'bg-amber-500' : 'bg-slate-700'}`}>
              <div
                className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-transform duration-300 ${
                  lowBandwidth ? 'translate-x-4' : 'translate-x-0.5'
                }`}
              />
            </div>
            <div className="flex items-center gap-1.5">
              {lowBandwidth ? (
                <WifiOff className="h-3.5 w-3.5 text-amber-400" />
              ) : (
                <Wifi className="h-3.5 w-3.5 text-slate-400" />
              )}
              <span className={`text-xs font-medium ${lowBandwidth ? 'text-amber-300' : 'text-slate-300'}`}>
                2G / Low-Bandwidth
              </span>
            </div>
          </button>

          {/* CTA Button */}
          <button
            onClick={onOpenScan}
            className="group relative flex items-center gap-2 overflow-hidden rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-600 px-3 py-2 md:px-4 md:py-2.5 text-sm font-semibold text-white shadow-lg shadow-emerald-500/25 transition-all hover:shadow-emerald-500/40 hover:brightness-110"
          >
            <span className="absolute inset-0 animate-pulse-slow rounded-lg bg-emerald-400/30" />
            <Plus className="relative h-4 w-4" strokeWidth={2.5} />
            <span className="relative hidden md:inline">Scan & Report Sick Crop</span>
            <span className="relative md:hidden">Scan</span>
          </button>
        </div>
      </div>
    </nav>
  );
}
