import { useState } from 'react';
import type { OutbreakPin } from '../types';
import {
  MapPin,
  Wind,
  Droplets,
  Clock,
  CheckCircle2,
  X,
  Leaf,
  FlaskConical,
  Crosshair,
  Navigation,
  Layers,
  Cloud,
} from 'lucide-react';

interface RadarMapProps {
  pins: OutbreakPin[];
  activeFilter: string;
  onFilterChange: (filter: string) => void;
  spreadPredictor: boolean;
  onToggleSpreadPredictor: () => void;
}

const cropFilterMap: Record<string, string> = {
  'All Crops': 'all',
  Tomato: 'tomato',
  'Corn/Maize': 'maize',
  Wheat: 'wheat',
  Rice: 'rice',
};

export default function RadarMap({
  pins,
  activeFilter,
  onFilterChange,
  spreadPredictor,
  onToggleSpreadPredictor,
}: RadarMapProps) {
  const [selectedPin, setSelectedPin] = useState<OutbreakPin | null>(null);

  const filteredPins =
    activeFilter === 'All Crops'
      ? pins
      : pins.filter((p) => p.cropType === cropFilterMap[activeFilter]);

  const severityConfig = {
    critical: {
      ring: 'bg-red-500',
      border: 'border-red-400',
      label: 'Critical',
      badge: 'bg-red-500/20 text-red-300 border-red-500/30',
      glow: 'shadow-red-500/50',
    },
    warning: {
      ring: 'bg-amber-500',
      border: 'border-amber-400',
      label: 'Warning',
      badge: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
      glow: 'shadow-amber-500/40',
    },
    resolved: {
      ring: 'bg-emerald-500',
      border: 'border-emerald-400',
      label: 'Resolved',
      badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
      glow: 'shadow-emerald-500/30',
    },
  };

  return (
    <div className="flex h-full flex-col rounded-2xl border border-slate-800 bg-slate-900/50 overflow-hidden">
      {/* Map Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 bg-slate-900/80 px-4 py-3">
        <div className="flex items-center gap-2">
          <Crosshair className="h-5 w-5 text-emerald-500" />
          <h2 className="text-sm font-bold text-white">Live Radar Map</h2>
          <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-medium text-emerald-400">
            Maharashtra Region
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <Layers className="h-3.5 w-3.5 text-slate-500" />
          <span className="text-[10px] text-slate-500">Satellite + Field Grid</span>
        </div>
      </div>

      {/* Filter Chips + Spread Predictor */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 bg-slate-950/50 px-4 py-2.5">
        <div className="flex flex-wrap gap-1.5">
          {['All Crops', 'Tomato', 'Corn/Maize', 'Wheat', 'Rice'].map((filter) => (
            <button
              key={filter}
              onClick={() => onFilterChange(filter)}
              className={`rounded-full px-3 py-1 text-xs font-medium transition-all ${
                activeFilter === filter
                  ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-200'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
        <button
          onClick={onToggleSpreadPredictor}
          className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
            spreadPredictor
              ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
              : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700'
          }`}
        >
          <Wind className="h-3.5 w-3.5" />
          48h Spread Predictor
          {spreadPredictor && (
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-sky-400 opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-sky-500" />
            </span>
          )}
        </button>
      </div>

      {/* Map Canvas */}
      <div className="relative flex-1 min-h-[420px] overflow-hidden bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900">
        {/* Grid pattern background */}
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `
              linear-gradient(rgba(16, 185, 129, 0.15) 1px, transparent 1px),
              linear-gradient(90deg, rgba(16, 185, 129, 0.15) 1px, transparent 1px)
            `,
            backgroundSize: '40px 40px',
          }}
        />

        {/* Topographic curves */}
        <svg className="absolute inset-0 h-full w-full opacity-30" preserveAspectRatio="none">
          <defs>
            <radialGradient id="terrain1" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#1e293b" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#0f172a" stopOpacity="0" />
            </radialGradient>
          </defs>
          <ellipse cx="30%" cy="40%" rx="200" ry="120" fill="url(#terrain1)" />
          <ellipse cx="70%" cy="60%" rx="180" ry="100" fill="url(#terrain1)" />
          <path
            d="M0,100 Q150,80 300,120 T600,100"
            fill="none"
            stroke="#334155"
            strokeWidth="1"
            opacity="0.4"
          />
          <path
            d="M0,200 Q200,180 400,220 T800,200"
            fill="none"
            stroke="#334155"
            strokeWidth="1"
            opacity="0.3"
          />
          <path
            d="M0,300 Q250,280 500,320 T1000,300"
            fill="none"
            stroke="#334155"
            strokeWidth="1"
            opacity="0.2"
          />
        </svg>

        {/* Radar sweep overlay */}
        <div className="pointer-events-none absolute left-1/2 top-1/2 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2">
          <div className="absolute inset-0 rounded-full border border-emerald-500/10" />
          <div className="absolute inset-[100px] rounded-full border border-emerald-500/10" />
          <div className="absolute inset-[200px] rounded-full border border-emerald-500/10" />
          <div className="absolute inset-0 animate-radar-sweep rounded-full">
            <div
              className="absolute inset-0 rounded-full"
              style={{
                background: 'conic-gradient(from 0deg, transparent 0deg, rgba(16, 185, 129, 0.12) 30deg, transparent 60deg)',
              }}
            />
          </div>
        </div>

        {/* Water bodies */}
        <svg className="absolute bottom-0 left-0 w-full h-24 opacity-20" preserveAspectRatio="none">
          <path d="M0,60 Q100,40 200,60 T400,50 T600,60 T800,50 T1000,60 L1000,100 L0,100 Z" fill="#1e3a5f" />
        </svg>

        {/* Location labels */}
        <div className="absolute left-[15%] top-[20%] text-[10px] font-medium text-slate-600">
          Sector 3
        </div>
        <div className="absolute right-[20%] top-[25%] text-[10px] font-medium text-slate-600">
          Sector 2
        </div>
        <div className="absolute left-[25%] bottom-[30%] text-[10px] font-medium text-slate-600">
          Sector 7
        </div>
        <div className="absolute right-[15%] bottom-[25%] text-[10px] font-medium text-slate-600">
          Sector 4
        </div>

        {/* User location marker */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="relative flex h-5 w-5 items-center justify-center">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-sky-400 opacity-50" />
            <div className="relative h-3 w-3 rounded-full bg-sky-500 ring-2 ring-sky-300" />
          </div>
          <span className="absolute left-6 top-1/2 -translate-y-1/2 whitespace-nowrap text-[10px] font-medium text-sky-300">
            You are here
          </span>
        </div>

        {/* Outbreak Pins */}
        {filteredPins.map((pin) => {
          const config = severityConfig[pin.severity];
          const showCone = spreadPredictor && pin.severity !== 'resolved';

          return (
            <div
              key={pin.id}
              className="absolute"
              style={{ left: `${pin.x}%`, top: `${pin.y}%` }}
            >
              {/* Spread predictor cone */}
              {showCone && (
                <SpreadCone
                  windDirection={pin.windDirection}
                  windSpeed={pin.windSpeed}
                  humidity={pin.humidity}
                  severity={pin.severity}
                />
              )}

              {/* Pin */}
              <button
                onClick={() => setSelectedPin(pin)}
                className="relative z-10 -translate-x-1/2 -translate-y-1/2"
              >
                {pin.severity !== 'resolved' && (
                  <span
                    className={`absolute inset-0 animate-pulse-ring rounded-full ${config.ring} opacity-60`}
                  />
                )}
                <div
                  className={`relative flex h-7 w-7 items-center justify-center rounded-full ${config.ring} border-2 ${config.border} shadow-lg ${config.glow} transition-transform hover:scale-125`}
                >
                  <MapPin className="h-4 w-4 text-white" strokeWidth={2.5} />
                </div>
                {/* Label */}
                <div className="absolute left-1/2 top-full z-10 mt-1 -translate-x-1/2 whitespace-nowrap rounded bg-slate-900/90 px-1.5 py-0.5 text-[9px] font-medium text-slate-300 backdrop-blur-sm">
                  {pin.distanceKm}km
                </div>
              </button>
            </div>
          );
        })}

        {/* Wind indicator */}
        <div className="absolute right-3 top-3 flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-900/80 px-3 py-2 backdrop-blur-sm">
          <Wind className="h-4 w-4 text-sky-400" />
          <div className="text-xs">
            <span className="font-semibold text-white">14 km/h</span>
            <span className="text-slate-500"> NE</span>
          </div>
        </div>

        {/* Humidity indicator */}
        <div className="absolute right-3 bottom-3 flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-900/80 px-3 py-2 backdrop-blur-sm">
          <Droplets className="h-4 w-4 text-sky-400" />
          <div className="text-xs">
            <span className="font-semibold text-white">84%</span>
            <span className="text-slate-500"> Humidity</span>
          </div>
        </div>

        {/* Compass */}
        <div className="absolute left-3 top-3 flex h-10 w-10 items-center justify-center rounded-full border border-slate-700 bg-slate-900/80 backdrop-blur-sm">
          <Navigation className="h-5 w-5 text-emerald-400" />
          <span className="absolute -top-1 text-[8px] font-bold text-slate-500">N</span>
        </div>

        {/* Scale */}
        <div className="absolute left-3 bottom-3 flex items-center gap-2">
          <div className="h-1 w-16 rounded-full border border-slate-600 bg-gradient-to-r from-transparent via-slate-400 to-transparent" />
          <span className="text-[10px] text-slate-500">2 km</span>
        </div>

        {/* Popup Card */}
        {selectedPin && (
          <PopupCard pin={selectedPin} onClose={() => setSelectedPin(null)} severityConfig={severityConfig} />
        )}
      </div>
    </div>
  );
}

function SpreadCone({
  windDirection,
  windSpeed,
  humidity,
  severity,
}: {
  windDirection: string;
  windSpeed: number;
  humidity: number;
  severity: string;
}) {
  const directionAngles: Record<string, number> = {
    'North-East': 45,
    East: 90,
    'South-West': 225,
    North: 0,
  };
  const angle = directionAngles[windDirection] ?? 45;
  const color = severity === 'critical' ? 'rgba(239, 68, 68, 0.15)' : 'rgba(245, 158, 11, 0.15)';
  const strokeColor = severity === 'critical' ? 'rgba(239, 68, 68, 0.5)' : 'rgba(245, 158, 11, 0.5)';

  return (
    <div
      className="pointer-events-none absolute left-0 top-0 z-0"
      style={{ transform: `rotate(${angle}deg)`, transformOrigin: '0 0' }}
    >
      <svg width="160" height="100" className="overflow-visible">
        <defs>
          <linearGradient id={`cone-${severity}-${windDirection}`} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={color} stopOpacity="0.5" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        <path
          d="M0,0 L150,-50 L150,50 Z"
          fill={`url(#cone-${severity}-${windDirection})`}
          stroke={strokeColor}
          strokeWidth="1"
          strokeDasharray="4 2"
        >
          <animate attributeName="stroke-dashoffset" from="0" to="12" dur="1s" repeatCount="indefinite" />
        </path>
        {/* Animated particles */}
        <circle r="2" fill={strokeColor}>
          <animateMotion dur="2s" repeatCount="indefinite" path="M0,0 L130,0" />
        </circle>
        <circle r="1.5" fill={strokeColor}>
          <animateMotion dur="2.5s" repeatCount="indefinite" path="M0,0 L130,-15" />
        </circle>
        <circle r="1.5" fill={strokeColor}>
          <animateMotion dur="2.8s" repeatCount="indefinite" path="M0,0 L130,15" />
        </circle>
      </svg>
    </div>
  );
}

function PopupCard({
  pin,
  onClose,
  severityConfig,
}: {
  pin: OutbreakPin;
  onClose: () => void;
  severityConfig: Record<string, { ring: string; border: string; label: string; badge: string; glow: string }>;
}) {
  const config = severityConfig[pin.severity];

  return (
    <div className="absolute left-1/2 top-1/2 z-30 w-[300px] -translate-x-1/2 -translate-y-1/2 animate-scale-in">
      <div className="overflow-hidden rounded-xl border border-slate-700 bg-slate-900/95 shadow-2xl backdrop-blur-xl">
        {/* Header */}
        <div className={`flex items-start justify-between border-b border-slate-800 px-4 py-3 ${pin.severity === 'critical' ? 'bg-red-500/10' : pin.severity === 'warning' ? 'bg-amber-500/10' : 'bg-emerald-500/10'}`}>
          <div className="flex items-center gap-2">
            <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${config.ring}`}>
              <MapPin className="h-5 w-5 text-white" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">{pin.crop}</h3>
              <p className="text-xs text-slate-400">{pin.pest}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-300">
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Body */}
        <div className="space-y-3 px-4 py-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${config.badge}`}>
              {config.label}
            </span>
            <span className="flex items-center gap-1 text-xs text-slate-400">
              <Clock className="h-3 w-3" />
              {pin.date} • {pin.time}
            </span>
            <span className="flex items-center gap-1 text-xs text-slate-400">
              <MapPin className="h-3 w-3" />
              {pin.distanceKm} km away
            </span>
          </div>

          <p className="text-xs italic text-slate-500">{pin.scientificName}</p>

          {/* Conditions */}
          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-2 text-center">
              <Wind className="mx-auto h-3.5 w-3.5 text-sky-400" />
              <p className="mt-1 text-xs font-bold text-white">{pin.windSpeed} km/h</p>
              <p className="text-[9px] text-slate-500">{pin.windDirection}</p>
            </div>
            <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-2 text-center">
              <Droplets className="mx-auto h-3.5 w-3.5 text-sky-400" />
              <p className="mt-1 text-xs font-bold text-white">{pin.humidity}%</p>
              <p className="text-[9px] text-slate-500">Humidity</p>
            </div>
            <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-2 text-center">
              {pin.verified ? (
                <>
                  <CheckCircle2 className="mx-auto h-3.5 w-3.5 text-emerald-400" />
                  <p className="mt-1 text-xs font-bold text-emerald-400">Verified</p>
                  <p className="text-[9px] text-slate-500">Field check</p>
                </>
              ) : (
                <>
                  <Cloud className="mx-auto h-3.5 w-3.5 text-amber-400" />
                  <p className="mt-1 text-xs font-bold text-amber-400">Unverified</p>
                  <p className="text-[9px] text-slate-500">AI photo</p>
                </>
              )}
            </div>
          </div>

          {/* Treatment */}
          <div className="space-y-2">
            <div>
              <div className="flex items-center gap-1.5">
                <Leaf className="h-3.5 w-3.5 text-emerald-400" />
                <p className="text-xs font-semibold text-emerald-400">Organic Remedies</p>
              </div>
              <ul className="mt-1 space-y-1">
                {pin.organicRemedies.slice(0, 2).map((remedy, i) => (
                  <li key={i} className="flex gap-1.5 text-[11px] text-slate-400">
                    <span className="text-emerald-500">•</span>
                    {remedy}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <FlaskConical className="h-3.5 w-3.5 text-sky-400" />
                <p className="text-xs font-semibold text-sky-400">Chemical Controls</p>
              </div>
              <ul className="mt-1 space-y-1">
                {pin.chemicalControls.slice(0, 2).map((control, i) => (
                  <li key={i} className="flex gap-1.5 text-[11px] text-slate-400">
                    <span className="text-sky-500">•</span>
                    {control}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-2">
            <p className="text-[10px] text-slate-500">Reported by {pin.reporter}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
