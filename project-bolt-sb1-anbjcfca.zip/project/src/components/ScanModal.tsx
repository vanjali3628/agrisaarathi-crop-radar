import { useState, useEffect } from 'react';
import type { ScanResult } from '../types';
import { testCases } from '../data';
import {
  X,
  Camera,
  Upload,
  Image as ImageIcon,
  Microscope,
  Volume2,
  Play,
  Pause,
  Leaf,
  FlaskConical,
  Radio,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  Brain,
  ScanLine,
  SprayCan,
  ShieldCheck,
} from 'lucide-react';

interface ScanModalProps {
  onClose: () => void;
  onBroadcast: (result: ScanResult) => void;
}

type Step = 'input' | 'analyzing' | 'result';

export default function ScanModal({ onClose, onBroadcast }: ScanModalProps) {
  const [step, setStep] = useState<Step>('input');
  const [result, setResult] = useState<ScanResult | null>(null);
  const [selectedTest, setSelectedTest] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [audioPlaying, setAudioPlaying] = useState(false);

  const runDiagnosis = (testKey: string) => {
    setSelectedTest(testKey);
    setStep('analyzing');
    setTimeout(() => {
      const tc = testCases[testKey];
      setResult({
        disease: tc.disease,
        scientificName: tc.scientificName,
        confidence: tc.confidence,
        severity: tc.severity,
        crop: tc.crop,
        organicRemedies: tc.organicRemedies,
        chemicalControls: tc.chemicalControls,
        isHealthy: tc.isHealthy,
        recommendation: tc.recommendation,
      });
      setStep('result');
    }, 2800);
  };

  const handleBroadcast = () => {
    if (result) {
      onBroadcast(result);
    }
  };

  const toggleAudio = () => setAudioPlaying(!audioPlaying);

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative z-10 w-full max-w-2xl max-h-[90vh] overflow-hidden rounded-2xl border border-slate-700 bg-slate-900 shadow-2xl animate-scale-in">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900/80 px-5 py-3">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-700">
              <Microscope className="h-4 w-4 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Scan & Diagnose Crop</h2>
              <p className="text-[10px] text-slate-500">AI-powered disease detection</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-300 transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Step indicator */}
        <div className="flex items-center gap-2 border-b border-slate-800 bg-slate-950/50 px-5 py-2">
          <StepDot active={step === 'input'} done={step !== 'input'} label="Capture" num={1} />
          <div className={`h-px flex-1 ${step !== 'input' ? 'bg-emerald-500' : 'bg-slate-700'}`} />
          <StepDot active={step === 'analyzing'} done={step === 'result'} label="Analyze" num={2} />
          <div className={`h-px flex-1 ${step === 'result' ? 'bg-emerald-500' : 'bg-slate-700'}`} />
          <StepDot active={step === 'result'} done={false} label="Result" num={3} />
        </div>

        {/* Content */}
        <div className="max-h-[calc(90vh-120px)] overflow-y-auto scrollbar-thin">
          {step === 'input' && (
            <InputStep
              isDragging={isDragging}
              setIsDragging={setIsDragging}
              onTest={runDiagnosis}
            />
          )}
          {step === 'analyzing' && <AnalyzingStep selectedTest={selectedTest} />}
          {step === 'result' && result && (
            <ResultStep
              result={result}
              audioPlaying={audioPlaying}
              onToggleAudio={toggleAudio}
              onBroadcast={handleBroadcast}
              onClose={onClose}
            />
          )}
        </div>
      </div>
    </div>
  );
}

function StepDot({ active, done, label, num }: { active: boolean; done: boolean; label: string; num: number }) {
  return (
    <div className="flex items-center gap-1.5">
      <div
        className={`flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold transition-all ${
          done
            ? 'bg-emerald-500 text-white'
            : active
            ? 'bg-emerald-500/20 text-emerald-400 ring-2 ring-emerald-500/40'
            : 'bg-slate-800 text-slate-500'
        }`}
      >
        {done ? <CheckCircle2 className="h-3.5 w-3.5" /> : num}
      </div>
      <span className={`text-[10px] font-medium ${active || done ? 'text-slate-200' : 'text-slate-600'}`}>
        {label}
      </span>
    </div>
  );
}

function InputStep({
  isDragging,
  setIsDragging,
  onTest,
}: {
  isDragging: boolean;
  setIsDragging: (v: boolean) => void;
  onTest: (key: string) => void;
}) {
  return (
    <div className="space-y-4 p-5">
      {/* Drag & drop area */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragging(false);
        }}
        className={`flex flex-col items-center justify-center rounded-xl border-2 border-dashed py-10 transition-all ${
          isDragging
            ? 'border-emerald-500 bg-emerald-500/10'
            : 'border-slate-700 bg-slate-950/50 hover:border-slate-600'
        }`}
      >
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-slate-800">
          <Upload className="h-6 w-6 text-slate-400" />
        </div>
        <p className="mt-3 text-sm font-medium text-slate-300">Drag & drop a crop photo here</p>
        <p className="mt-1 text-xs text-slate-500">or use a demo button below for instant testing</p>
        <div className="mt-4 flex gap-2">
          <button className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/60 px-3 py-1.5 text-xs text-slate-300 transition-colors hover:bg-slate-700">
            <Camera className="h-3.5 w-3.5" />
            Open Camera
          </button>
          <button className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/60 px-3 py-1.5 text-xs text-slate-300 transition-colors hover:bg-slate-700">
            <ImageIcon className="h-3.5 w-3.5" />
            Browse Files
          </button>
        </div>
      </div>

      {/* Divider */}
      <div className="flex items-center gap-3">
        <div className="h-px flex-1 bg-slate-800" />
        <span className="text-[10px] font-medium text-slate-500">OR USE INSTANT DEMO</span>
        <div className="h-px flex-1 bg-slate-800" />
      </div>

      {/* Test buttons */}
      <div className="space-y-2">
        <TestButton
          emoji="🍅"
          label="Test 1: Tomato Late Blight"
          description="Critical fungal infection"
          severity="critical"
          onClick={() => onTest('test-1')}
        />
        <TestButton
          emoji="🌽"
          label="Test 2: Corn Fall Armyworm"
          description="Pest infestation — urgent"
          severity="critical"
          onClick={() => onTest('test-2')}
        />
        <TestButton
          emoji="🥔"
          label="Test 3: Healthy Potato Leaf"
          description="No disease detected"
          severity="resolved"
          onClick={() => onTest('test-3')}
        />
      </div>
    </div>
  );
}

function TestButton({
  emoji,
  label,
  description,
  severity,
  onClick,
}: {
  emoji: string;
  label: string;
  description: string;
  severity: string;
  onClick: () => void;
}) {
  const severityColor =
    severity === 'critical'
      ? 'border-red-500/30 hover:border-red-500/50 hover:bg-red-500/5'
      : 'border-emerald-500/30 hover:border-emerald-500/50 hover:bg-emerald-500/5';

  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-xl border bg-slate-950/40 p-3 transition-all ${severityColor}`}
    >
      <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-slate-800 text-xl">
        {emoji}
      </div>
      <div className="flex-1 text-left">
        <p className="text-sm font-semibold text-white">{label}</p>
        <p className="text-xs text-slate-500">{description}</p>
      </div>
      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-800">
        <ScanLine className="h-4 w-4 text-emerald-400" />
      </div>
    </button>
  );
}

function AnalyzingStep({ selectedTest }: { selectedTest: string | null }) {
  const test = selectedTest ? testCases[selectedTest] : null;

  return (
    <div className="flex flex-col items-center justify-center py-12 px-5">
      <div className="relative flex h-24 w-24 items-center justify-center">
        <div className="absolute inset-0 animate-pulse-ring rounded-full bg-emerald-500/30" />
        <div className="absolute inset-2 animate-pulse-ring-slow rounded-full bg-emerald-500/20" />
        <div className="relative flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-emerald-700 shadow-xl shadow-emerald-500/30">
          <Brain className="h-9 w-9 text-white" />
        </div>
      </div>

      <h3 className="mt-6 text-sm font-bold text-white">AI Analyzing Crop Image...</h3>
      <p className="mt-1 text-xs text-slate-400">Running convolutional neural network model</p>

      {/* Progress steps */}
      <div className="mt-6 w-full max-w-sm space-y-2">
        {[
          { label: 'Preprocessing image data', done: false },
          { label: 'Extracting leaf features', done: false },
          { label: 'Matching disease database (12,400 samples)', done: false },
          { label: 'Computing confidence score', done: false },
        ].map((item, i) => (
          <div key={i} className="flex items-center gap-2" style={{ animationDelay: `${i * 0.5}s` }}>
            <Loader2 className="h-3.5 w-3.5 animate-spin text-emerald-400" />
            <span className="text-xs text-slate-400">{item.label}</span>
          </div>
        ))}
      </div>

      {test && (
        <div className="mt-6 flex items-center gap-2 rounded-lg bg-slate-800/60 px-3 py-2">
          <span className="text-lg">{test.emoji}</span>
          <span className="text-xs text-slate-400">Analyzing: {test.crop} leaf sample</span>
        </div>
      )}
    </div>
  );
}

function ResultStep({
  result,
  audioPlaying,
  onToggleAudio,
  onBroadcast,
  onClose,
}: {
  result: ScanResult;
  audioPlaying: boolean;
  onToggleAudio: () => void;
  onBroadcast: () => void;
  onClose: () => void;
}) {
  const [confidence, setConfidence] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      const interval = setInterval(() => {
        setConfidence((prev) => {
          if (prev >= result.confidence) {
            clearInterval(interval);
            return result.confidence;
          }
          return prev + 2;
        });
      }, 20);
    }, 200);
    return () => clearTimeout(timer);
  }, [result.confidence]);

  const isHealthy = result.isHealthy;
  const severityColor =
    result.severity === 'critical'
      ? 'text-red-400 bg-red-500/15 border-red-500/30'
      : result.severity === 'warning'
      ? 'text-amber-400 bg-amber-500/15 border-amber-500/30'
      : 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30';

  return (
    <div className="space-y-4 p-5 animate-slide-up">
      {/* Result header */}
      <div className={`rounded-xl border p-4 ${isHealthy ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-red-500/30 bg-red-500/5'}`}>
        <div className="flex items-start gap-3">
          <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${isHealthy ? 'bg-emerald-500/20' : 'bg-red-500/20'}`}>
            {isHealthy ? (
              <ShieldCheck className="h-6 w-6 text-emerald-400" />
            ) : (
              <AlertTriangle className="h-6 w-6 text-red-400" />
            )}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white">{result.disease}</h3>
              <span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${severityColor}`}>
                {result.severity === 'critical' ? 'CRITICAL' : result.severity === 'warning' ? 'WARNING' : 'HEALTHY'}
              </span>
            </div>
            <p className="text-xs italic text-slate-500">{result.scientificName}</p>
            <p className="text-xs text-slate-400 mt-1">Detected on: {result.crop}</p>
          </div>
        </div>

        {/* Confidence meter */}
        <div className="mt-4">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-medium text-slate-400">AI Confidence</span>
            <span className="text-sm font-bold text-white">{confidence.toFixed(1)}%</span>
          </div>
          <div className="h-2.5 overflow-hidden rounded-full bg-slate-800">
            <div
              className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-emerald-400 transition-all duration-300"
              style={{ width: `${confidence}%` }}
            />
          </div>
        </div>
      </div>

      {/* Audio Advisory */}
      {!isHealthy && (
        <div className="rounded-xl border border-slate-700 bg-slate-950/50 p-3">
          <button
            onClick={onToggleAudio}
            className="flex w-full items-center justify-between"
          >
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sky-500/20">
                <Volume2 className="h-4 w-4 text-sky-400" />
              </div>
              <div className="text-left">
                <p className="text-xs font-semibold text-white">Audio Advisory</p>
                <p className="text-[10px] text-slate-500">Listen to voice advisory in local language</p>
              </div>
            </div>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-800">
              {audioPlaying ? (
                <Pause className="h-4 w-4 text-sky-400" />
              ) : (
                <Play className="h-4 w-4 text-sky-400" />
              )}
            </div>
          </button>

          {audioPlaying && (
            <div className="mt-3 flex items-center gap-1 animate-fade-in">
              {Array.from({ length: 32 }).map((_, i) => (
                <div
                  key={i}
                  className="flex-1 rounded-full bg-sky-400/60 animate-wave"
                  style={{
                    height: `${8 + Math.sin(i * 0.5) * 12 + Math.random() * 6}px`,
                    animationDelay: `${i * 0.05}s`,
                  }}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Recommendation */}
      <div className="rounded-xl border border-slate-700 bg-slate-800/30 p-3">
        <p className="text-xs text-slate-300">
          <span className="font-semibold text-white">Recommendation: </span>
          {result.recommendation}
        </p>
      </div>

      {/* Treatment */}
      {!isHealthy && (
        <div className="grid gap-3 md:grid-cols-2">
          {/* Organic */}
          <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-3">
            <div className="flex items-center gap-1.5 mb-2">
              <Leaf className="h-4 w-4 text-emerald-400" />
              <h4 className="text-xs font-bold text-emerald-400">Organic Remedies</h4>
            </div>
            <ul className="space-y-1.5">
              {result.organicRemedies.map((remedy, i) => (
                <li key={i} className="flex gap-1.5 text-[11px] text-slate-300">
                  <span className="text-emerald-500 mt-0.5">•</span>
                  {remedy}
                </li>
              ))}
            </ul>
          </div>

          {/* Chemical */}
          <div className="rounded-xl border border-sky-500/20 bg-sky-500/5 p-3">
            <div className="flex items-center gap-1.5 mb-2">
              <FlaskConical className="h-4 w-4 text-sky-400" />
              <h4 className="text-xs font-bold text-sky-400">Chemical Controls</h4>
            </div>
            <ul className="space-y-1.5">
              {result.chemicalControls.map((control, i) => (
                <li key={i} className="flex gap-1.5 text-[11px] text-slate-300">
                  <span className="text-sky-500 mt-0.5">•</span>
                  {control}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Action buttons */}
      <div className="flex gap-2 pt-2">
        {!isHealthy && (
          <button
            onClick={onBroadcast}
            className="group relative flex flex-1 items-center justify-center gap-2 overflow-hidden rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-600 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-emerald-500/25 transition-all hover:brightness-110"
          >
            <span className="absolute inset-0 animate-pulse-slow rounded-lg bg-emerald-400/20" />
            <Radio className="relative h-4 w-4" />
            <span className="relative">Broadcast Outbreak to Regional Grid</span>
          </button>
        )}
        <button
          onClick={onClose}
          className="rounded-lg border border-slate-700 bg-slate-800 px-4 py-3 text-sm font-medium text-slate-300 transition-colors hover:bg-slate-700"
        >
          {isHealthy ? 'Done' : 'Close'}
        </button>
      </div>
    </div>
  );
}
