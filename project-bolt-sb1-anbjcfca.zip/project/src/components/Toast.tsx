import { useEffect, useState } from 'react';
import { CheckCircle2, AlertTriangle, Info, X, Zap } from 'lucide-react';

export type ToastType = 'success' | 'warning' | 'info';

export interface ToastData {
  id: string;
  type: ToastType;
  title: string;
  message: string;
}

interface ToastProps {
  toasts: ToastData[];
  onDismiss: (id: string) => void;
}

export default function Toast({ toasts, onDismiss }: ToastProps) {
  return (
    <div className="fixed bottom-6 right-6 z-[100] flex flex-col gap-3">
      {toasts.map((toast) => (
        <ToastItem key={toast.id} toast={toast} onDismiss={onDismiss} />
      ))}
    </div>
  );
}

function ToastItem({ toast, onDismiss }: { toast: ToastData; onDismiss: (id: string) => void }) {
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setExiting(true);
      setTimeout(() => onDismiss(toast.id), 300);
    }, 4500);
    return () => clearTimeout(timer);
  }, [toast.id, onDismiss]);

  const config = {
    success: {
      icon: CheckCircle2,
      color: 'emerald',
      bg: 'bg-emerald-500/10',
      border: 'border-emerald-500/30',
      iconColor: 'text-emerald-400',
    },
    warning: {
      icon: AlertTriangle,
      color: 'amber',
      bg: 'bg-amber-500/10',
      border: 'border-amber-500/30',
      iconColor: 'text-amber-400',
    },
    info: {
      icon: Info,
      color: 'sky',
      bg: 'bg-sky-500/10',
      border: 'border-sky-500/30',
      iconColor: 'text-sky-400',
    },
  };

  const { icon: Icon, bg, border, iconColor } = config[toast.type];

  return (
    <div
      className={`flex items-start gap-3 rounded-xl border ${border} ${bg} backdrop-blur-xl px-4 py-3 shadow-2xl min-w-[320px] max-w-[420px] ${
        exiting ? 'animate-fade-in opacity-0' : 'animate-slide-in-right'
      }`}
    >
      <Icon className={`mt-0.5 h-5 w-5 flex-shrink-0 ${iconColor}`} />
      <div className="flex-1">
        <p className="text-sm font-semibold text-white">{toast.title}</p>
        <p className="text-xs text-slate-400 mt-0.5">{toast.message}</p>
      </div>
      <button
        onClick={() => {
          setExiting(true);
          setTimeout(() => onDismiss(toast.id), 300);
        }}
        className="flex-shrink-0 text-slate-500 hover:text-slate-300 transition-colors"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}

export function LowBandwidthBanner() {
  return (
    <div className="flex items-center gap-2 border-b border-amber-500/20 bg-amber-500/10 px-4 py-2 md:px-6">
      <Zap className="h-4 w-4 text-amber-400 flex-shrink-0" />
      <p className="text-xs font-medium text-amber-200">
        2G Ultra-Low Data Mode Active (Saves 95% bandwidth for rural connections)
      </p>
    </div>
  );
}
