import type { OutbreakPin, Report, SMSDispatch } from './types';

export const initialPins: OutbreakPin[] = [
  {
    id: 'pin-1',
    crop: 'Tomatoes',
    cropType: 'tomato',
    pest: 'Late Blight',
    scientificName: 'Phytophthora infestans',
    severity: 'critical',
    distanceKm: 2.1,
    x: 38,
    y: 42,
    date: 'Oct 14, 2026',
    time: '06:42 AM',
    humidity: 84,
    windSpeed: 14,
    windDirection: 'North-East',
    organicRemedies: [
      'Apply copper-based fungicide spray (3g/L water) every 7 days',
      'Remove and destroy infected leaves to slow spread',
      'Apply neem oil solution (5ml/L) as preventive measure',
    ],
    chemicalControls: [
      'Mancozeb 75% WP at 2.5g/L — spray within 24 hours',
      'Metalaxyl + Mancozeb (Ridomil Gold) for severe infection',
      'Cymoxanil-based fungicide for systemic protection',
    ],
    reporter: 'Rajesh K. (Sector 4)',
    verified: true,
  },
  {
    id: 'pin-2',
    crop: 'Maize',
    cropType: 'maize',
    pest: 'Fall Armyworm',
    scientificName: 'Spodoptera frugiperda',
    severity: 'critical',
    distanceKm: 4.8,
    x: 58,
    y: 28,
    date: 'Oct 13, 2026',
    time: '05:15 PM',
    humidity: 72,
    windSpeed: 11,
    windDirection: 'East',
    organicRemedies: [
      'Deploy pheromone traps (2 per acre) to monitor adult moths',
      'Spray neem-based formulation (Azadirachtin 5%) at 3ml/L',
      'Handpick larvae from whorls in early morning hours',
      'Introduce natural predators: Trichogramma wasps',
    ],
    chemicalControls: [
      'Emamectin Benzoate 5% SG at 0.4g/L — targeted whorl application',
      'Chlorantraniliprole (Coragen) 18.5% SC at 0.5ml/L',
      'Spinosad 45% SC at 0.3ml/L for organic-compatible control',
    ],
    reporter: 'Community Scout Team B',
    verified: true,
  },
  {
    id: 'pin-3',
    crop: 'Cucurbits',
    cropType: 'tomato',
    pest: 'Powdery Mildew',
    scientificName: 'Podosphaera xanthii',
    severity: 'warning',
    distanceKm: 7.5,
    x: 22,
    y: 62,
    date: 'Oct 12, 2026',
    time: '11:30 AM',
    humidity: 65,
    windSpeed: 8,
    windDirection: 'South-West',
    organicRemedies: [
      'Spray potassium bicarbonate solution (5g/L) weekly',
      'Apply milk-water solution (1:9 ratio) as foliar spray',
      'Improve airflow by pruning dense foliage',
    ],
    chemicalControls: [
      'Sulphur-based fungicide (Wettable Sulphur) at 3g/L',
      'Tebuconazole 25.9% EC at 1ml/L for active infection',
      'Azoxystrobin (Amistar) 23% SC at 1ml/L alternately',
    ],
    reporter: 'Lakshmi P. (Sector 7)',
    verified: false,
  },
  {
    id: 'pin-4',
    crop: 'Wheat',
    cropType: 'wheat',
    pest: 'Leaf Rust (Treated)',
    scientificName: 'Puccinia triticina',
    severity: 'resolved',
    distanceKm: 11,
    x: 70,
    y: 68,
    date: 'Oct 5, 2026',
    time: '09:00 AM',
    humidity: 40,
    windSpeed: 5,
    windDirection: 'North',
    organicRemedies: [
      'Field treated successfully with resistant variety rotation',
      'Applied compost tea for immune system boost',
    ],
    chemicalControls: [
      'Propiconazole 25% EC applied — field cleared on Oct 10',
      'Buffer zone established to prevent reinfection',
    ],
    reporter: 'Cooperative Society Unit 3',
    verified: true,
  },
];

export const initialReports: Report[] = [
  {
    id: 'r1',
    crop: 'Tomatoes',
    cropType: 'tomato',
    pest: 'Late Blight',
    distanceKm: 2.1,
    timeAgo: '12 min ago',
    verified: true,
    reporter: 'Rajesh K.',
    emoji: '🍅',
  },
  {
    id: 'r2',
    crop: 'Maize',
    cropType: 'maize',
    pest: 'Fall Armyworm',
    distanceKm: 4.8,
    timeAgo: '2 hours ago',
    verified: true,
    reporter: 'Scout Team B',
    emoji: '🌽',
  },
  {
    id: 'r3',
    crop: 'Rice',
    cropType: 'rice',
    pest: 'Blast Disease',
    distanceKm: 6.3,
    timeAgo: '5 hours ago',
    verified: false,
    reporter: 'Anjali S.',
    emoji: '🌾',
  },
  {
    id: 'r4',
    crop: 'Cucurbits',
    cropType: 'tomato',
    pest: 'Powdery Mildew',
    distanceKm: 7.5,
    timeAgo: '8 hours ago',
    verified: false,
    reporter: 'Lakshmi P.',
    emoji: '🥒',
  },
  {
    id: 'r5',
    crop: 'Wheat',
    cropType: 'wheat',
    pest: 'Leaf Rust (Treated)',
    distanceKm: 11,
    timeAgo: '2 days ago',
    verified: true,
    reporter: 'Coop Society',
    emoji: '🌾',
  },
  {
    id: 'r6',
    crop: 'Potato',
    cropType: 'potato',
    pest: 'Early Blight',
    distanceKm: 9.2,
    timeAgo: '3 days ago',
    verified: true,
    reporter: 'Mahendra T.',
    emoji: '🥔',
  },
];

export const initialDispatches: SMSDispatch[] = [
  {
    id: 'd1',
    message:
      '🚨 ALERT: Tomato Late Blight confirmed 2.1km from your field. High humidity tonight favors spore spread. Action: Apply Mancozeb or organic copper spray within 24h. Reply 1 for nearest fungicide depot.',
    recipients: 38,
    sector: 'Sector 4',
    time: '06:45 AM',
    status: 'sent',
  },
  {
    id: 'd2',
    message:
      '⚠️ ADVISORY: Fall Armyworm larvae detected in maize fields 4.8km away. Inspect whorls for damage. Reply 2 for free pheromone trap distribution points.',
    recipients: 24,
    sector: 'Sector 2',
    time: '05:20 PM',
    status: 'sent',
  },
];

export const testCases: Record<
  string,
  {
    disease: string;
    scientificName: string;
    confidence: number;
    severity: 'critical' | 'warning' | 'resolved';
    crop: string;
    cropType: string;
    emoji: string;
    organicRemedies: string[];
    chemicalControls: string[];
    isHealthy: boolean;
    recommendation: string;
  }
> = {
  'test-1': {
    disease: 'Late Blight',
    scientificName: 'Phytophthora infestans',
    confidence: 97.4,
    severity: 'critical',
    crop: 'Tomato',
    cropType: 'tomato',
    emoji: '🍅',
    organicRemedies: [
      'Apply copper-based fungicide spray (3g/L water) every 7 days',
      'Remove and destroy infected leaves immediately',
      'Apply neem oil solution (5ml/L) as preventive barrier',
    ],
    chemicalControls: [
      'Mancozeb 75% WP at 2.5g/L — spray within 24 hours',
      'Metalaxyl + Mancozeb (Ridomil Gold) for severe cases',
      'Cymoxanil-based fungicide for systemic protection',
    ],
    isHealthy: false,
    recommendation:
      'Immediate action required. High contagion risk due to 84% humidity. Broadcast alert to neighboring farms.',
  },
  'test-2': {
    disease: 'Fall Armyworm',
    scientificName: 'Spodoptera frugiperda',
    confidence: 94.8,
    severity: 'critical',
    crop: 'Maize',
    cropType: 'maize',
    emoji: '🌽',
    organicRemedies: [
      'Deploy pheromone traps (2 per acre) to monitor moths',
      'Spray Azadirachtin 5% (neem) at 3ml/L on whorls',
      'Handpick larvae from whorls at dawn',
      'Release Trichogramma wasps as biological control',
    ],
    chemicalControls: [
      'Emamectin Benzoate 5% SG at 0.4g/L — whorl application',
      'Chlorantraniliprole (Coragen) 18.5% SC at 0.5ml/L',
      'Spinosad 45% SC at 0.3ml/L',
    ],
    isHealthy: false,
    recommendation:
      'Urgent: Armyworm spreads rapidly. Treat within 48 hours and alert neighboring maize fields.',
  },
  'test-3': {
    disease: 'No Disease Detected',
    scientificName: 'Solanum tuberosum (Healthy)',
    confidence: 99.1,
    severity: 'resolved',
    crop: 'Potato',
    cropType: 'potato',
    emoji: '🥔',
    organicRemedies: [
      'Continue regular irrigation schedule (25mm/week)',
      'Apply compost mulch to retain soil moisture',
      'Maintain crop rotation practice every 3 seasons',
    ],
    chemicalControls: [
      'No chemical intervention needed at this time',
      'Preventive: Monitor for aphid populations weekly',
    ],
    isHealthy: true,
    recommendation:
      'Your crop is healthy! Continue good farming practices and weekly monitoring.',
  },
};

export const cropFilters = ['All Crops', 'Tomato', 'Corn/Maize', 'Wheat', 'Rice'];
