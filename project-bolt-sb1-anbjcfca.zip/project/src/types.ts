export type Severity = 'critical' | 'warning' | 'resolved';

export interface OutbreakPin {
  id: string;
  crop: string;
  cropType: 'tomato' | 'maize' | 'wheat' | 'rice' | 'potato';
  pest: string;
  scientificName: string;
  severity: Severity;
  distanceKm: number;
  x: number;
  y: number;
  date: string;
  time: string;
  humidity: number;
  windSpeed: number;
  windDirection: string;
  organicRemedies: string[];
  chemicalControls: string[];
  reporter: string;
  verified: boolean;
}

export interface Report {
  id: string;
  crop: string;
  cropType: string;
  pest: string;
  distanceKm: number;
  timeAgo: string;
  verified: boolean;
  reporter: string;
  emoji: string;
}

export interface SMSDispatch {
  id: string;
  message: string;
  recipients: number;
  sector: string;
  time: string;
  status: 'sent' | 'pending';
}

export type ScanResult = {
  disease: string;
  scientificName: string;
  confidence: number;
  severity: Severity;
  crop: string;
  organicRemedies: string[];
  chemicalControls: string[];
  isHealthy: boolean;
  recommendation: string;
};
